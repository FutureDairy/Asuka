package com.zero;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PageInfo
{
	private static int ConnectTimeout = 10*1000;
	private static int PicConnectTimeout = 20*1000;
	private static int UrlPageReadTimeout = 90*1000;   /////  ������ַҳ������ʱ
	private static int PicPageReadTimeout = 60*1000;     /////  ����ͼƬҳ������ʱ
	private static int PicReadTimeout = 90*1000;       /////  ����ͼƬ ����ʱ

	public static String picType = ".jpg";
	public static String host = "http://ba8segirl.com/";
	public static String baseDirection = "C:\\Users\\Administrator.PC201402141720\\Desktop\\crawlerPic\\";
	private String picPageName;
	private String folderPath;
	private String baseFolder = "";
	private String baseDir = baseDirection;

	/**
	 * ƥ��ؼ���
	 */
	protected String filter;
	/**
	 * �ų��ؼ���
	 */
	protected String filterExclude;
	protected FILTERMODE filterMode = FILTERMODE.OR;
	public static String filterSeparator = ",";
	protected enum FILTERMODE{AND,OR}

	private String html;

	/**
	 * �Ƿ�����ͼƬ��ȡ��ʱ
	 */
	private boolean isTimedOut = false;
	private int index = 0;
	protected int savedPicNum = 0;
	protected int curThreadNum = 0;
	protected static int MAX_THEAD_NUM = 5;
	private Queue<String> picUrls = new ArrayDeque<String>();

	protected String url;

	public String getPage() {
		return url;
	}

	public void setPage(String url) {

		this.url = url;
	}

	public String getBaseDir() {

		return this.baseDir;
	}

	public void addChildFolder(String folder)
	{
		this.baseFolder += folder + "\\";
	}

	public void setBaseDir(String otherBaseDir)
	{
		if(otherBaseDir == null)
		{
			return ;
		}

		String[] tmp = otherBaseDir.split("\\\\");
		int end = otherBaseDir.length();

		if(tmp.length > 1)
		{ 
			int i = tmp.length-1;

			if(!tmp[i].equals("\\\\"))
			{
				end = otherBaseDir.lastIndexOf(tmp[i]) + tmp[i].length();
			}
		}

		otherBaseDir = otherBaseDir.substring(0, end);

		this.baseDir = otherBaseDir + "\\";
	}

	public PageInfo()
	{

	}

	public PageInfo(String url)
	{
		this.url = url;
	}

	public static ArrayList<String> getAllPicURI(String html)
	{
		if(html == null)
		{
			return null;
		}

		ArrayList<String> urls = new ArrayList<String>();

		String left = "<img src=\"http://";
		String right = "\"";
		String regex = left+".*?"+right;

		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		String picUrl;

		while(m.find())
		{
			picUrl = m.group().substring(left.length());   ////  remove <img src=\"http://
			picUrl = picUrl.substring(0, picUrl.length()-right.length());
			urls.add("http://"+picUrl);
		}

		/*
		 * 
		int head = 0, foot = 0; 
		String picUrl = "";
		while((head = html.indexOf(left)+left.length()) > 0
				&& (foot = html.indexOf(right, head)) > 0)
		{
			picUrl = html.substring(head, foot);

			if(picUrl.endsWith(".jpg"))
			{
				urls.add("http://"+ picUrl);
			}

			html = html.substring(foot);
			head = 0;
			foot = 0;
		}
		 */

		return urls;
	}

	public static void saveAllPic(String url, final String path)
	{
		String html = loadPicPage(url);

		if("".equals(html))     ///////    ����read time out��ͼƬҳ
		{
			System.out.println("��û���κ�ͼƬ: "+url);

			return ;
		}

		if(html != null 
				&& html.indexOf("timed out") > 0)     ///////   ����read time out��ͼƬҳ
		{
			System.out.println("loadPicPage failed: "+html+": "+url);
			Util.saveFailedUrl(url, path, "failedPicPage.txt");

			return ;
		}

		ArrayList<String> pics = getAllPicURI(html);

		if(pics == null)
		{
			System.out.println("���ҵ�ͼƬ��ַ��"+url);

			return ;
		}

		int picNum = pics.size();

		if(picNum < 1)
		{
			System.out.println("ͼƬ��Ϊ0!");

			return ;
		}

		System.out.println("ͼƬ��: "+ picNum);

		Util.createFolder(path);
		Util.saveUrl(url, path+ "url.txt");
		System.out.println("��ʼ���浽: "+path);

		for (final String picUrl : pics)
		{
			new Thread(new Runnable() {

				public void run() {
					// TODO Auto-generated method stub

					savePic(picUrl, path);
				}
			}).start();
		}
	}

	void saveAllPic()
	{
		//System.out.println("����"+ url +"��ͼƬ��ַ��...");

		this.html = loadPicPage(url);

		if("".equals(html))     ///////   ����read time out��ͼƬҳ
		{
			System.out.println("��û���κ�ͼƬ: "+url);

			return ;
		}

		if(html != null)  ///////   ����read time out��ͼƬҳ
		{
			picPageName = getPageName(html);

			if(picPageName == null)
			{
				picPageName = "tmp";
			}

			folderPath = baseDir + baseFolder + picPageName + "\\";

			if(html.indexOf("timed out") > 0)
			{
				System.out.println("loadPicPage failed: "+html+": "+url);
				Util.saveFailedUrl(url, baseDir + baseFolder, "failedPicPage.txt"); 

				return ;
			}
		}

		ArrayList<String> pics = getAllPicURI(html);

		if(pics == null)
		{
			System.out.println("���ҵ�ͼƬ��ַ��"+url);

			return ;
		}

		int picNum = pics.size();

		if(picNum < 1)
		{
			System.out.println("ͼƬ��Ϊ0!");

			return ;
		}

		System.out.println("ͼƬ��: "+ picNum);

		Util.createFolder(folderPath);
		Util.saveUrl(url, folderPath+ "url.txt");
		System.out.println("��ʼ���浽: "+folderPath);

		picUrls.addAll(pics);
		int size = picUrls.size();

		if(size > MAX_THEAD_NUM)
		{
			size = MAX_THEAD_NUM;
		}

		for (int i = 0; i < size; i++)
		{
			new Thread(new Runnable() {

				public void run() {
					// TODO Auto-generated method stub

					savePic(picUrls.poll());
				}
			}).start();
		}
	}

	private static boolean readPic(String url, String filePath) throws IOException
	{
		long fileLen = 0;

		if(!Util.isFileExist(filePath))
		{
			fileLen = downloadPic(url, filePath);
		}
		else
		{
			String tmpName = filePath+"_tmp";
			File tmpFile = new File(filePath+"_tmp");

			fileLen = downloadPic(url, tmpName);

			/**
			 * �����ͼƬδ������ȫ  
			 * �����ص�ͼƬ���������滻����
			 */
			if(Util.getFileLen(filePath) < fileLen)
			{
				Util.deleteFile(filePath);
				Util.renameFile(tmpName, filePath); 
			}
			else
			{
				Util.deleteFile(tmpFile);

				return false;    /////  �����㱣��
			}
		}

		if(fileLen > 0)
		{
			System.out.println("ͼƬ�Ѽ������: "+filePath);
		}
		else
		{
			return false;
		}

		return true;
	}

	protected static long downloadPic(String url, String filePath) throws IOException
	{ 
		// ����URL
		URL openUrl = new URL(url); 
		// ������   
		URLConnection con = openUrl.openConnection();

		/**
		 * ���������ͷ��Ҫ
		 */
		con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36");
		con.setConnectTimeout(PicConnectTimeout);
		con.setReadTimeout(PicReadTimeout);

		// ����ʵ�ʵ�����
		con.connect();

		// ������  
		InputStream is = con.getInputStream();

		// 1K�����ݻ���  
		byte[] bs = new byte[1024];
		// ��ȡ�������ݳ���  
		int len;
		int fileLen = 0;

		OutputStream os = new FileOutputStream(filePath);

		// ��ʼ��ȡ
		while ((len = is.read(bs)) != -1) 
		{  
			os.write(bs, 0, len);
			fileLen+=len;
		}

		// ��ϣ��ر���������
		os.close();  
		is.close();

		return fileLen;
	}

	private void savePic(String url)
	{
		if(url == null)
		{
			return ;
		}

		++curThreadNum;
		//System.out.println("������1������: ������ "+ ++curThreadNum +" ���߳�__��ʣ "+picUrls.size()+" ��ҳ��δ����");

		String filePath = folderPath + getPicName(url);

		if(Util.isFileExist(filePath))
		{
			//		return ;
		}

		try {

			if(readPic(url, filePath))
			{
				savedPicNum++;
			}

		} catch (IOException e) {

			if(e.toString().indexOf("timed out") > 0)
			{
				System.out.println("readPic failed: "+e+": "+filePath);
				isTimedOut = true;
			}
			else
			{
				e.printStackTrace();
			}
		} 

		if(--curThreadNum < MAX_THEAD_NUM)
		{
			url = picUrls.poll();

			if(url != null)
			{
				savePic(url);
			}
			else if(curThreadNum <= 0)
			{
				/**
				 * ��ͼƬ��ַ��ʧЧ�� ���ɶҲû���� �Ҳ����ڳ�ʱ��� ��ֱ��ɾ���ļ���
				 */
				if(Util.picNumInFolder(folderPath) <= 0    ////  ����ļ��ж����� savedPicNum ��׼ȷ
						&& !isTimedOut
						&& savedPicNum <= 0
						)
				{
					Util.deleteFolder(folderPath);
				}
			}
		}
	}

	public static void savePic(String url, String filePath)
	{
		if(url == null)
		{
			return ;
		}

		if(Util.isFileExist(filePath))
		{
			//		return ;
		}

		url = url.replaceFirst("-fpage-\\d*", "");

		try {

			readPic(url, filePath);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	String getPageName(String html)
	{
		if(html == null)
		{
			System.out.println("getPageName failed");
			return null;
		}

		String head = "<h1 id=\"subject_tpc\">";
		int left = html.indexOf(head);
		int right = html.indexOf("</h1>");

		if(left < 0 || right < 0)
		{
			System.out.println("getPageName failed:  "+url);

			return null;
		}

		String name = html.substring(left + head.length(), right);

		name = name.replaceAll("&.{4};", ""); 
		name = name.replaceAll("[<>\"'?]", "");

		return name;
	}

	String getPicName(String url)
	{
		if(url == null)
		{
			return null;
		}

		//System.out.println(url);
		int left = url.lastIndexOf("/");
		int right = url.lastIndexOf(".");

		if(left < 0 || right < 0)
		{
			return null;
		}

		return url.substring(left+1, right+".jpg".length());
	}

	public static class Util
	{
		static String fileNamesInFolder(String folder, String separator)
		{
			if(isFileExist(folder))
			{
				File file = new File(folder);

				if(file != null)
				{
					File fileList[] = file.listFiles();
					String fileName = "";

					for (int j = 0; j < fileList.length; j++) 
					{
						fileName += fileList[j].getName() + separator;
					}

					return fileName;
				}
			}

			return null;
		}

		static String[] fileNamesInFolder(String folder)
		{
			if(isFileExist(folder))
			{
				File file = new File(folder);

				if(file != null)
				{
					File fileList[] = file.listFiles();
					String[] fileName = new String[fileList.length];

					for (int j = 0; j < fileList.length; j++) 
					{
						fileName[j] = fileList[j].getName();
					}

					return fileName;
				}
			}

			return null;
		}

		static int picNumInFolder(String folder)
		{
			int picNum = 0;

			if(isFileExist(folder))
			{
				File file = new File(folder);

				if(file != null)
				{
					File[] fileList = file.listFiles();

					for(File f : fileList)
					{
						if(f.getName().indexOf(picType) > 0)
						{
							picNum++;
						}
					}
				}
			}

			return picNum;
		}

		static void renameFile(String oldname,String newname)
		{ 
			if(!oldname.equals(newname)){//�µ��ļ�������ǰ�ļ�����ͬʱ,���б�Ҫ���������� 
				File oldfile=new File(oldname); 
				File newfile=new File(newname);

				if(!oldfile.exists()){
					return;//�������ļ�������
				}
				if(newfile.exists())//���ڸ�Ŀ¼���Ѿ���һ���ļ������ļ�����ͬ�������������� 
					System.out.println(newname+"�Ѿ����ڣ�"); 
				else{ 
					oldfile.renameTo(newfile); 
				} 
			}else{
				System.out.println("���ļ����;��ļ�����ͬ...");
			}
		}

		static long getFileLen(String path)
		{
			return new File(path).length();
		}

		static void deleteFile(String path)
		{
			deleteFile(new File(path));
		}

		static void deleteFile(File file)
		{
			file.delete();
		}

		static void deleteFolder(String folder)
		{
			File file = new File(folder);

			if (file.isDirectory())
			{ 
				File[] files = file.listFiles(); //����Ŀ¼�����е��ļ� files[];

				for (int i = 0;i < files.length;i ++)
				{   //����Ŀ¼�����е��ļ�  
					deleteFile(files[i]);//��ÿ���ļ�������������е���  
				}  
			}

			file.delete();//ɾ���ļ��� 
		}

		static String getFileName(String filePath)
		{
			if(filePath == null)
			{
				return null;
			}

			int left = filePath.lastIndexOf("\\");

			if(left < 0)
			{
				return filePath;
			}

			return filePath.substring(left+1);
		}

		static boolean isFileExist(String path)
		{
			return new File(path).exists();
		}

		static void createFolder(String path)
		{
			File sf = new File(path);

			if(!sf.exists())
			{
				if(!sf.mkdirs())
				{
					System.out.println("�ļ��д���ʧ�ܣ�"+path);
				}
			}
		}

		public static String readFile(String path)
		{
			String content = "";

			try {

				FileReader fr = new FileReader(new File(path));
				BufferedReader bf = new BufferedReader(fr);
				String line;

				while((line = bf.readLine()) != null)
				{
					content += line+"\n";
				}

				bf.close();
				fr.close();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return content;
		}

		public static String findRexString(String html, String regex)
		{
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(html);

			if(m.find())
			{
				return m.group();
			}

			return null; 
		}

		public static void saveFailedUrl(String url, String path, String fileName)
		{ 
			File file = new File(path);

			if(!isFileExist(path))
			{
				createFolder(path);
			}

			try {

				file = new File(path+"\\"+fileName);

				if(!file.exists())
				{
					file.createNewFile();
				}

				String content = readFile(path+"\\"+fileName).replaceAll(url+"\r\n", "");
				FileOutputStream fout = new FileOutputStream(file);
				fout.write((content+url+"\r\n").getBytes());
				fout.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public static void saveUrl(String url, String path)
		{
			File file = new File(path);

			try {

				FileOutputStream fout = new FileOutputStream(file);
				fout.write(url.getBytes());
				fout.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * ��ָ��URL����GET����������
	 *  
	 */
	public static String loadPicPage(String url) 
	{
		if(url == null)
		{
			System.out.println("loadPicPage is null");

			return null;	
		}

		String result = "";
		BufferedReader in = null;
		boolean start = false;

		try {

			String urlNameString = url;
			URL realUrl = new URL(urlNameString);

			// �򿪺�URL֮�������
			URLConnection connection = realUrl.openConnection();

			// ����ͨ�õ���������	
			//	connection.setRequestProperty("Cookie", cookie);
			connection.setConnectTimeout(ConnectTimeout);  
			connection.setReadTimeout(PicPageReadTimeout);  

			// ����ʵ�ʵ�����
			connection.connect();

			int code = ((HttpURLConnection)connection).getResponseCode();

			if (code == 200)
			{
				//	System.out.println("loadPicPage success!");
			}
			else
			{
				System.out.println("loadPicPage fail! ");

				return null;
			}

			// ���� BufferedReader����������ȡURL����Ӧ
			in = new BufferedReader(new InputStreamReader(
					connection.getInputStream(), "utf-8"));
			String line;

			int left;

			while ((line = in.readLine()) != null)
			{
				left = line.indexOf("read_tpc");

				if(line.indexOf("subject_tpc") > 0)
				{
					result += line;
				}

				/**
				 * ����ֻץȡͼƬ��ַ��������ҳ��ȫ��
				 */
				if( left > 0 || start)
				{
					start = true;
					result += line;
					// System.out.println(line);

					if(line.indexOf("div", left) > 0)
					{ 
						break;
					}
				}
			}

		} catch (Exception e) {
			System.out.println("����GET��������쳣��");

			if(e.toString().indexOf("timed out") < 0)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			else if(result.length() <= 1)
			{
				return e.toString();
			}
		}
		// ʹ��finally�����ر�������
		finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		//System.out.println(result);

		return result;
	}

	public static String loadUrlPage(String url)
	{
		if(url == null)
		{
			return null;
		}

		String result = "";
		BufferedReader in = null;

		try {

			String urlNameString = url;
			URL realUrl = new URL(urlNameString);

			// �򿪺�URL֮�������
			URLConnection connection = realUrl.openConnection();

			// ����ͨ�õ��������� 
			connection.setConnectTimeout(ConnectTimeout);
			connection.setReadTimeout(UrlPageReadTimeout); 

			// ����ʵ�ʵ�����
			connection.connect();

			int code = ((HttpURLConnection)connection).getResponseCode();

			if (code == 200)
			{
				//	System.out.println("loadUrlPage success!");
			}
			else
			{
				System.out.println("loadUrlPage fail! ");

				return null;
			}

			// ���� BufferedReader����������ȡURL����Ӧ
			in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));

			String line;
			boolean isStart = false;

			while ((line = in.readLine()) != null)
			{
				//	System.out.println(isStart+line);

				if(line.indexOf("a_ajax_") >= 0 || isStart)   ////  ���⿪ʼ
				{
					isStart = true; 
					result += line;
					//System.out.println("======"+line);
				}

				if(isStart && line.indexOf("</table>") > 0)
				{
					break;
				}
			} 

		} catch (Exception e) {
			System.out.println("����GET��������쳣��");

			if(e.toString().indexOf("timed out") < 0)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			else if(result.length() <= 1)
			{
				return e.toString();
			}
		}
		// ʹ��finally�����ر�������
		finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		//System.out.println(result);

		return result;
	} 

	public static ArrayList<String> wholePageUrl(String url, String header, String cookie)
	{
		return wholePagesUrl(url, null, null, FILTERMODE.OR);
	}

	public static ArrayList<String> wholePagesUrl(String url, String filter, String filterExclude, FILTERMODE mode)
	{
		String html = loadUrlPage(url);
		//System.out.println("wholePage: "+html);

		if(html == null)
		{
			return null;
		}

		if(html.indexOf("timed out") > 0)
		{
			System.out.println("loadUrlPage failed: "+html+": "+url);
			Util.saveFailedUrl(url, PageInfo.baseDirection+filter, "failedUrlPage.txt");

			return null;
		}

		String regex = "<a href=\"read-htm-tid-\\d*(-fpage-\\d*)*.html\" id=\"a_ajax_\\d*\"( target=\"\")* class=\"subject\".*?</a>"; 

		ArrayList<String> urls = new ArrayList<String>();
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);

		String href;

		while(m.find())
		{
			href = m.group();
			int left,right;

			if(filter != null
					|| filterExclude != null)
			{
				left = href.indexOf("subject");

				/**
				 * û�ҵ��ؼ���  �Ҳ�ƥ���ų��Ĺؼ���
				 */
				if(!filterUrl(href.substring(left), filter, filterExclude, mode))
				{
					continue;
				}
				else
				{
					//System.out.println("���˳ɹ�: "+href);
				}
			}

			left = href.indexOf("href=")+ "href=".length();
			right = href.indexOf("id=");
			href = host + href.substring(left, right).replaceAll("\"", "");
			href = href.replaceFirst("-fpage-\\d*", "");

			urls.add(href.trim());
		}

		return urls;
	}

	protected static boolean filterUrl(String url, String filter, String filterExclude, FILTERMODE mode)
	{
		boolean isMatch = false;

		if(filter != null)
		{
			String[] filters = filter.split(filterSeparator);

			/**
			 * ��һ���ؼ���ûƥ�䵽��Ϊ��
			 */
			for(String str : filters)
			{
				if(Util.findRexString(url, str.trim()) == null)
				{
					if(mode == FILTERMODE.AND)  ////  ��Ϊͬʱƥ�����ؼ���
					{
						return false;
					}
				}
				else if(mode == FILTERMODE.OR)  ////  ��Ϊƥ��������ؼ���
				{
					isMatch = true;
					break;
				}
			}
		}

		if(filterExclude != null)
		{
			String[] filtersExclude = filterExclude.split(filterSeparator);

			/**
			 * ƥ�䵽һ���ų��Ĺؼ���ҲΪ��
			 */
			for(String str : filtersExclude)
			{
				if(Util.findRexString(url, str.trim()) != null)
				{
					isMatch = false;
				}
			}
		}

		return isMatch;
	}

	/**
	 * �Ӳ�ƥ��Ĺؼ����г�ȥ��Ҫƥ��Ĺؼ���
	 * @param filter
	 * @param filterExclude
	 * @return
	 */
	protected static String removeFilter(String filter, String filterExclude)
	{
		if(filter == null
				|| filterExclude == null)
		{
			return filterExclude;
		}

		String[] filters = filter.split(filterSeparator);

		for(String key : filters)
		{
			filterExclude = filterExclude.replaceAll(key.trim(), "");
		}

		return filterExclude;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
		folderPath = folderPath.replaceFirst("_index", index+"");
	}

	public String getFilter() {
		return filter;
	}

	public void setFilterMode(FILTERMODE filterMode) {

		this.filterMode = filterMode;
	}

	public void setFilter(String filter) {

		this.filter = filter;

		/**
		 * ��ֹ��ƥ��Ĺؼ����ﺬ��Ҫƥ��� Key word
		 */
		this.filterExclude = removeFilter(filter, filterExclude);
	}

	public void addFilter(String filter) {

		if(this.filter == null)
		{
			this.filter = filter;
		}
		else
		{
			this.filter += filterSeparator+filter;
		}

		/**
		 * ��ֹ��ƥ��Ĺؼ����ﺬ��Ҫƥ��� Key word
		 */
		this.filterExclude = removeFilter(filter, filterExclude);
	}

	public String getFilterExclude() {
		return filterExclude;
	}

	public void setFilterExclude(String filterExclude) {

		this.filterExclude = filterExclude;

		/**
		 * ��ֹ��ƥ��Ĺؼ����ﺬ��Ҫƥ��� Key word
		 */
		this.filterExclude = removeFilter(filter, filterExclude);
	}

	public void addFilterExclude(String filterExclude) {

		if(this.filterExclude == null)
		{
			this.filterExclude = filterExclude;
		}
		else
		{
			this.filterExclude += filterSeparator+filterExclude;
		}

		/**
		 * ��ֹ��ƥ��Ĺؼ����ﺬ��Ҫƥ��� Key word
		 */
		this.filterExclude = removeFilter(filter, filterExclude);
	}
}
