package com.zero;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

public class PageMgr extends PageInfo
{   
	/**
	 * 分页网址
	 */
	private Queue<String> urlPages = new ArrayDeque<String>();

	/**
	 * 图片页网址
	 */
	private Queue<String> allPagesUrl = new ArrayDeque<String>();

	private String childFolder;

	private int wholePageNum = 0;
	private int pageFinished = 0;
	protected static int MAX_THEAD_NUM = 5;

	public PageMgr()
	{

	}

	public PageMgr(String url)
	{
		urlPages.add(url);
	}

	public PageMgr(String urlModel, int startPage, int endPage)
	{
		if(startPage > endPage)
		{
			return ;
		}

		for( ; startPage <= endPage; startPage++)
		{
			urlPages.add(urlModel.replaceFirst("_index", startPage +""));
		}

		this.url = urlModel;
	} 

	public void addPage(String page)
	{
		urlPages.add(page);
	}

	public void startDownloadByPicPage()
	{
		/**
		 * 过滤每个主题页，找到要找的页面立即开始
		 */
		for(String page : urlPages)
		{ 
			System.out.println("遍历: "+ page +"中...");
			ArrayList<String> pagesUrl = wholePagesUrl(page, filter, filterExclude, filterMode);

			if(pagesUrl == null || pagesUrl.size() < 1)
			{
				if(filter == null && filterExclude == null)
				{
					System.out.println("页面： "+page+"下没找到图片页！");
				}
				else
				{
					if(filter != null && filterExclude == null)
					{
						System.out.println("页面： "+page+"下没找到关键字为: {"+filter+"}(模式:"+filterMode+") 的图片页！");
					}
					else if(filter == null && filterExclude != null)
					{  
						System.out.println("页面： "+page+"下没找到排除关键字: {"+filterExclude+"} 的图片页！");
					}
					else
					{
						System.out.println("页面： "+page+"下没找到关键字为: {"+filter+"}(模式:"+filterMode+")且排除: {"+filterExclude+"} 的图片页！");
					}
				}

				continue;
			}

			for(final String pageUrl : pagesUrl)
			{
				if(curThreadNum >= MAX_THEAD_NUM)
				{
					allPagesUrl.add(pageUrl);    //////   所有图片页面地址
					wholePageNum++;
				}
				else
				{
					new Thread(new Runnable() {
						public void run() {

							downloadByPicPage(pageUrl);
						}
					}).start();
				}
			}
		}
	}

	public void startDownloadByMainPage()
	{ 
		int size = urlPages.size();

		if(size < 1)
		{
			return ;
		}

		if(size > MAX_THEAD_NUM)
		{
			size = MAX_THEAD_NUM;
		}

		for (int i = 0; i < size; i++)
		{
			new Thread(new Runnable() {
				public void run() {

					downloadByMainPage(urlPages.poll());
				}
			}).start();
		}
	}


	/**
	 * 每个图片页面开线程  
	 * 资源利用率高
	 * @param page
	 */
	public void downloadByPicPage(String picPage)
	{
		if(picPage == null)
		{
			return ;
		}

		if(curThreadNum >= MAX_THEAD_NUM)
		{
			return ;
		}

		int times = pageFinished++ -MAX_THEAD_NUM;

		if(times < 0)
		{
			times = 0;
		}


		System.out.println("#添加了1个进程: 现在有 "+ ++curThreadNum +" 个图片页线程" +
				"\n#已完成: "+ times +" 个图片页面! 共有: " + ++wholePageNum +" 个图片页"
				+ "\n还剩 "+ allPagesUrl.size()+" 个页面未下载\n============\n");

		PageInfo pageInfo = new PageInfo(picPage);
		pageInfo.addChildFolder(childFolder);
		pageInfo.saveAllPic();  ////  忘记是异步执行的了

		if(--curThreadNum < MAX_THEAD_NUM)
		{ 
			final String url = allPagesUrl.poll();

			if(url != null)
			{
				new Thread(new Runnable() {
					public void run() {

						downloadByPicPage(url);
					} 
				}).start();
			}
			else if(curThreadNum <= 0)
			{
				System.out.println("图片页: "+picPage+" 已加载完毕！");

				return ;
			}
		}

	}

	/**
	 * 每个主页面开线程 
	 * 资源利用率低
	 * @param page
	 */
	public void downloadByMainPage(String page)
	{
		if(page == null)
		{
			return ;
		}

		if(curThreadNum >= MAX_THEAD_NUM)
		{
			return ;
		}

		int times = pageFinished++ -MAX_THEAD_NUM;

		if(times < 0)
		{
			times = 0;
		}

		System.out.println("#添加了1个进程: 现在有 "+ ++curThreadNum +" 个图片页线程" +
				"\n#已完成: "+ times +" 个图片页面! 共有: " + ++wholePageNum +" 个图片页"
				+ "\n还剩 "+ allPagesUrl.size()+" 个页面未下载\n============\n");

		ArrayList<String> pageUrls = wholePagesUrl(page, filter, filterExclude, filterMode);

		if(pageUrls == null)
		{
			System.out.println("没找到图片网页！");

			return ;
		}

		PageInfo pageInfo;

		for (String url : pageUrls)
		{
			pageInfo = new PageInfo(url); 
			pageInfo.addChildFolder(childFolder);
			pageInfo.saveAllPic();
		}

		if(--curThreadNum < MAX_THEAD_NUM)
		{ 
			final String url = urlPages.poll();

			if(url != null)
			{
				new Thread(new Runnable() {
					public void run() {

						downloadByMainPage(url);
					}		 
				}).start();
			}
			else if(curThreadNum <= 0)
			{
				System.out.println("主题页: "+page+" 已加载完毕！");

				return ;
			}
		}

	}

	public String getChildFolder() {
		return childFolder;
	}

	public void setBaseFolder(String childFolder) {
		this.childFolder = childFolder;
	}

	public void addChildFolder(String childFolder) {

		if(this.childFolder == null)
		{
			this.childFolder = childFolder;

			return ;
		}

		this.childFolder += "\\"+ childFolder;
	}


	public static void main(String[] args) {

		int startPage = 2;
		int endPage = 100;

		//	String url = "http://ba8segirl.com/read-htm-tid-5546049.html ";
		String model = "http://ba8segirl.com/thread-htm-fid-3-page-_index.html";

		/*PageInfo.savePic("http://s1.s8tu.com/2015/12/27/33ad6c0.jpg", "C:\\Users\\Administrator.PC201402141720\\Desktop\\121.jpg");

		PageInfo page = new PageInfo("http://ba8segirl.com/read-htm-tid-5328625.html");
		page.addChildFolder("Asian naked\\嫩");
		page.saveAllPic();
		 */
		/*
		1、连接 超时 ->导致 文件夹无图 :  savefailedUrl
		3、多个关键词
		 */

		//PageInfo.savePic("http://dl120.dix3.com/view?action=downfile&fid=sxedee3609aa1112bb79", PageInfo.baseDirection);

		String filter = "黄瓜,蒂法,明日香,asuka,回忆";
		String childFolder = "动漫";
		/**	
		 * 排除下载过的关键词
		 */
		String filterExclude = Util.fileNamesInFolder(baseDirection+childFolder, filterSeparator);

		PageMgr manager = new PageMgr(model, startPage, endPage);
		manager.addPage(model.replaceFirst("-page-_index", ""));
		manager.setFilter(filter);
		manager.setFilterExclude(filterExclude);
		manager.setBaseFolder(childFolder);
		manager.addChildFolder(filter);
		manager.startDownloadByPicPage();
	}

}
